#include "lab1-2.h" //uses lab1-2.h file to be able to work properly and be able to make function calls
#include <iostream> 
using namespace std; 

int main(){ 
    //calls to each function
    voidFunction(); 
    charFunction('j'); 
    intFunction(25); 
    floatFunction(25.59); 
}