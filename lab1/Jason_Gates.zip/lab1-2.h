
#include <iostream>
using namespace std;
//declares a group of functions and has their own corresponding variable types. All have argument lists too.
void voidFunction(void);
char charFunction(char i);
int intFunction(int i);
float floatFunction(float i);