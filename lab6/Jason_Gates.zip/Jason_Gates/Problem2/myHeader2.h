#include <iostream>
#include <string>
#include "myHeader1.h"
using namespace std;

namespace myNamespace2{ // making namespace

    void func3(){ // create fun3
        cout << "This is a message from Function 3! Function 3 is called! \n";
    }

    void func4(){ // create fun4
        cout << "This is a message from Function 4! Function 4 is called! \n";
    }
}