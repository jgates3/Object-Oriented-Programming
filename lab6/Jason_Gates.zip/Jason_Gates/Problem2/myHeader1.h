#include <iostream>
#include <string>
using namespace std;

namespace myNamespace{ // making namespace

    void func1(){ // creation of fun1
        cout << "This is a message from Function 1! Function 1 is called! \n";
    }

    void func2(){ // creation of fun2
        cout << "This is a message from Function 2! Function 2 is called! \n";
    }
}